package eu.pontsystems.javatanfolyam.car;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Szmzv02Pv01BackAndrasApplication {

	public static void main(String[] args) {
		SpringApplication.run(Szmzv02Pv01BackAndrasApplication.class, args);
	}

}
