package eu.pontsystems.javatanfolyam.car;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Szmzv02Pv01BackAndrasApplicationTests {

	@Test
	void contextLoads() {
	}

}
